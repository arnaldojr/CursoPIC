//**************************************************************************
// Exemplo 1:

// Este software est� preparado para demonstrar o controle dos pinos de I/O    
// o estado de um bot�o por meio de um led.

// Observa��o: Mudar a chave EN-LED para a posi��o ON

//**************************************************************************
#include <p18F4550.h>           //Defini��o de registradores

//***  Bits de configura��o do microcontrolador  ***************************

#pragma config FOSC = HS
#pragma config CPUDIV = OSC1_PLL2
#pragma config WDT = ON
#pragma config WDTPS = 128
#pragma config LVP = OFF
#pragma config PWRT = ON
#pragma config BOR = OFF
#pragma config BORV = 0
#pragma config PBADEN = OFF
#pragma config DEBUG = OFF
#pragma config PLLDIV = 1
#pragma config USBDIV = 1
#pragma config FCMEN = OFF
#pragma config IESO = OFF
#pragma config VREGEN = OFF
#pragma config MCLRE = ON
#pragma config LPT1OSC = OFF
#pragma config CCP2MX = ON
#pragma config STVREN = OFF
#pragma config ICPRT = OFF
#pragma config XINST = OFF

//*** Defini��es de labels *************************************************

#define botao PORTDbits.RD5     //Label botao para chave S5 (1:PRESSIONADO)

#define	led		PORTBbits.RB3   //Porta do led: 0(APAGADO), 1(ACESO)

#define	coluna1	PORTDbits.RD0   //IO de ativa��o da coluna 1 do teclado
                                    //(1:coluna ativada)

//**************************************************************************
void main(void)
{
	//Inicializa��es
    PORTA = 0x00;               //Limpa PORTA
    PORTB = 0x00;               //Limpa PORTB
    PORTC = 0x00;               //Limpa PORTC
    PORTD = 0x00;               //Limpa PORTD
    PORTE = 0x00;               //Limpa PORTE

    LATA = 0x00;                //Limpa PORTA
    LATB = 0x00;                //Limpa PORTB
    LATC = 0x00;                //Limpa PORTC
    LATD = 0x00;                //Limpa PORTD
    LATE = 0x00;                //Limpa PORTE

    TRISA = 0b11000011;         //CONFIG DIRE��O DOS PINOS PORTA
    TRISB = 0b00000000;         //CONFIG DIRE��O DOS PINOS PORTB
    TRISC = 0b11111111;         //CONFIG DIRE��O DOS PINOS PORTC
    TRISD = 0b11110000;         //CONFIG DIRE��O DOS PINOS PORTD
    TRISE = 0b00000111;         //CONFIG DIRE��O DOS PINOS PORTE

    ADCON1 = 0b00001111;        //DESLIGA CONVERSORES A/D

//***
    coluna1 = 1;                //ATIVA COLUNA 1 DO TECLADO MATRICIAL

//*** Loop principal
    while(1)
	{
        ClrWdt();
        if(botao)
			led = 1;	// testa bot�o. Se bot�o = 0, ent�o led = 1
        else
			led = 0;	// caso contr�rio, led = 0
    }
}   // FIM DO PROGRAMA
