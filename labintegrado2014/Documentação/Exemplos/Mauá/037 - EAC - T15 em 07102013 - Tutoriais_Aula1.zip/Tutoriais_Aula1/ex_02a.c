//**************************************************************************
// Exemplo 2:
//
// Este software est� preparado para demonstrar o tratamento de debounce
// t�pico de chaves mec�nicas
//
// Observa��o: Mudar a chave EN-LED para a posi��o ON

//**************************************************************************
#include <p18F4550.h>           //Defini��o de registradores

//***  Bits de configura��o do microcontrolador  ***************************

#pragma config FOSC = HS
#pragma config CPUDIV = OSC1_PLL2
#pragma config WDT = ON
#pragma config WDTPS = 128
#pragma config LVP = OFF
#pragma config PWRT = ON
#pragma config BOR = OFF
#pragma config BORV = 0
#pragma config PBADEN = OFF
#pragma config DEBUG = OFF
#pragma config PLLDIV = 1
#pragma config USBDIV = 1
#pragma config FCMEN = OFF
#pragma config IESO = OFF
#pragma config VREGEN = OFF
#pragma config MCLRE = ON
#pragma config LPT1OSC = OFF
#pragma config CCP2MX = ON
#pragma config STVREN = OFF
#pragma config ICPRT = OFF
#pragma config XINST = OFF

//*** Defini��es de vari�veis globais **************************************

unsigned char contador;
unsigned int filtro_btinc, filtro_btdec;

//*** Defini��es de constantes *********************************************

#define	MIN     1
#define	MAX		15
#define	reset_filtro	2000

//*** Defini��es de I/Os ***************************************************

#define btinc	PORTDbits.RD4	  //Chave usada para incrementar o contador
#define btdec	PORTDbits.RD5     //Chave usada para decrementar o contador
#define	coluna1	PORTDbits.RD0   //IO de ativa��o da coluna 1 do teclado
                                    //(1:coluna ativada)

//**************************************************************************
void main(void)
{
    PORTA = 0x00;               //Limpa PORTA
    PORTB = 0x00;               //Limpa PORTB
    PORTC = 0x00;               //Limpa PORTC
    PORTD = 0x00;               //Limpa PORTD
    PORTE = 0x00;               //Limpa PORTE

    TRISA = 0b11000011;         //CONFIG DIRE��O DOS PINOS PORTA
    TRISB = 0b00000000;         //CONFIG DIRE��O DOS PINOS PORTB
    TRISC = 0b11111111;         //CONFIG DIRE��O DOS PINOS PORTC
    TRISD = 0b11110000;         //CONFIG DIRE��O DOS PINOS PORTD
    TRISE = 0b00000111;         //CONFIG DIRE��O DOS PINOS PORTE

    ADCON1 = 0b00001111;        //DESLIGA CONVERSORES A/D

//*** Inicializa��o de vari�veis

    coluna1 = 1;                //ATIVA COLUNA 1 DO TECLADO MATRICIAL

    contador = MIN;
    PORTB = contador;

//*** Loop principal
    while(1)
    {
        ClrWdt();
        PORTB = contador;
        
        if(btinc)
		{
			filtro_btinc--;
			if(!filtro_btinc)
			{
				if(contador < MAX) contador++;
			}
		}
		else filtro_btinc = reset_filtro;
		
        if(btdec)
		{
			if(!(--filtro_btdec))
			{
				if(contador > MIN) contador--;
			}
		}
		else filtro_btdec = reset_filtro;

    }
} // bloco de c�digo da fun��o main
