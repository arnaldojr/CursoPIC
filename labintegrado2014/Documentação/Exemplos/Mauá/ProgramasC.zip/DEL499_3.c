/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *           Programa��o em C18 - Recursos B�sicos de programa��o        *
 *                               499_3.c                                 *
 *                                                                       *
 *              														 *
 *                          Eletr�nica Aplicada                          *
 *  																	 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *   VERS�O : 1.4 (Jos� Carlos)                                          *
 *   DATA : 06/10/2006                                          	   	 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                             Descri��o geral                           *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*	ESTE PROGRAMA IMPLEMENTA O CONTROLE DO AQUECEDOR (PWM) POR MEIO DO   *
 *  POTENCIOMETRO (MODO LOCAL) OU PELO COMPUTADOR (MODO REMOTO)          */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                		DEFINI��O PIC			         				 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <p18F452.h>        	 //Register definitions

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                INCLUDES DAS FUN��ES DE PERIF�RICOS DO PIC             *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#include <pwm.h>          		 //PWM library functions
#include <adc.h>           		 //ADC library functions
#include <timers.h>        		 //Timer library functions
#include <delays.h>           	 //Delay library functions
#include <stdlib.h>           	 //Library functions
#include <usart.h>           	 //USART library functions
#include <ctype.h>				 //Tipos em C
#include <math.h>				 //Math library functions

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                         Configura��es para grava��o                   *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#pragma config OSC = XT
#pragma config WDT = ON
#pragma config WDTPS = 4
#pragma config LVP = OFF

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *              Defini��o e inicializa��o das vari�veis Globais          *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
//Neste bloco est�o definidas as vari�veis globais do programa.

unsigned char	unidade;		// resultado conversao bcd
unsigned char	dezena;			// resultado conversao bcd
unsigned char	centena;		// resulatdo conversao bcd
unsigned char	usart_rx;		// valor recebido pela serial
		 char   pos_graph=0;	// posicao bar graph (prox. livre)
unsigned int	valor_pwm;		// valor do PWM em 10 bits
unsigned int	valor_temp;		// valor da temperatura em 10 bits
unsigned int	comando;		// comando recebido

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                           Constantes internas                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
//A defini��o de constantes facilita a programa��o e a manuten��o.

const rom unsigned char temp_table[ ] =
{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,
  2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,
  10,10,11,11,12,12,13,13,14,14,15,15,16,16,17,17,
  18,18,19,19,20,20,21,21,22,22,23,23,23,24,24,25,
  25,26,26,27,27,28,28,29,29,30,30,31,31,32,32,33,
  33,34,34,35,35,36,36,37,37,38,38,39,39,40,40,41,
  41,42,42,43,43,44,44,45,45,46,46,47,47,48,48,49,
  49,50,50,51,51,52,52,53,53,54,54,55,55,56,56,57,
  57,58,58,59,59,60,60,61,61,62,62,63,63,64,64,65,
  65,66,66,67,67,68,68,69,69,70,70,71,71,72,72,73,
  73,74,74,75,75,76,76,77,77,78,78,79,79,80,80,81,
  81,82,82,83,83,84,84,85,85,86,86,87,87,88,88,89,
  89,90,90,91,91,92,92,93,93,94,94,95,95,96,96,97,
  97,98,98,99,99,100,100,101,101,102,102,103,103,104,104,104,
  105,105,106,106,107,107,108,108,109,109,110,110,111,111,112,112};

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                    Declara��o dos flags de software                   *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
//A defini��o de flags ajuda na programa��o e economiza mem�ria RAM.

	struct{
		unsigned BIT0:1;
		unsigned BIT1:1;
	}FLAGSbits;

#define	ST_MOD		FLAGSbits.BIT0		//STATUS DO MODO L=0 / R=1
#define	ST_DIS		FLAGSbits.BIT1		//STATUS DO DISPLAY T=0 / P=1

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                   Defini��o e inicializa��o dos port's                *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                       PROTOTIPAGEM DE FUN��ES                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void comando_lcd(unsigned char caracter);
void escreve_lcd(unsigned char caracter);
void limpa_lcd(void);
void inicializa_lcd(void);
void tela_principal(void);
void converte_bcd(unsigned char aux);
void escreve_frase(const rom char *frase);
void escreve_pwm(unsigned int v_pwm);
void escreve_temp(unsigned int v_temp);
void inc_graph(void);
void dec_graph(void);
void escreve_graph(char n_ast);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                ENTRADAS                               *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// As entradas devem ser associadas a nomes para facilitar a programa��o e
//futuras altera��es do hardware.

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                 SA�DAS                                *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// AS SA�DAS DEVEM SER ASSOCIADAS A NOMES PARA FACILITAR A PROGRAMA��O E
//FUTURAS ALTERA��ES DO HARDWARE.

#define rs		PORTEbits.RE0	/* via do lcd que sinaliza recep��o de
								   dados ou comando */
#define enable	PORTEbits.RE1	// enable do lcd

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *					Rotina que envia um COMANDO para o LCD		         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void comando_lcd(unsigned char caracter)
{
	rs = 0;						// seleciona o envio de um comando
	PORTD = caracter;			// carrega o PORTD com o caracter
	enable = 1 ;				// gera pulso no enable
	Delay10TCYx(1);				// espera 10 microsegundos
	enable = 0;					// desce o pino de enable
	Delay10TCYx(4);				// espera m�nimo 40 microsegundos
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *				Rotina que envia um DADO a ser escrito no LCD            *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void escreve_lcd(unsigned char caracter)
{
	rs = 1;						// seleciona o envio de um dado
	PORTD = caracter;			// carrega o PORTD com o caracter
	enable = 1;					// gera pulso no enable
	Delay10TCYx(1);				// espera 10 microsegundos
	enable = 0;					// desce o pino de enable
	Delay10TCYx(4);				// espera m�nimo 40 microsegundos
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *						        Fun��o para limpar o LCD		         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void limpa_lcd(void)
{
	comando_lcd(0x01);			// limpa lcd	
	Delay1KTCYx(2);				// aguarda 2000 microsegundos (2ms)	
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *		     			Inicializa��o do Display de LCD			         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void inicializa_lcd(void)
{
	comando_lcd(0x30);			// envia comando para inicializar display
	Delay1KTCYx(4);				// espera 4 milisengundos

	comando_lcd(0x30);			// envia comando para inicializar display
	Delay10TCYx(10);			// espera 100 microsengundos

	comando_lcd(0x30);			// envia comando para inicializar display

	comando_lcd(0x38);			// liga o display, sem cursor e sem blink

	limpa_lcd();				// limpa lcd

	comando_lcd(0x0c);			// display sem cursor

	comando_lcd(0x06);			// desloca cursor para a direita
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *	                 		  Tela Principal					         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void tela_principal(void)
{
	comando_lcd(0x8F);			// posiciona o cursor na linha 0, coluna 0
	escreve_lcd('T');			// inicia com o bargraph em temperatura
	comando_lcd(0xC0);
	escreve_frase("TP:   C P:   % L"); // inicia em modo local
	comando_lcd(0xC5);
	escreve_lcd(0xDF);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *	                 		  Conversoes  						         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void converte_bcd(unsigned char aux)
{
	dezena = 0;
	centena = 0;
	while(aux >= 100)
	    {aux-=100;centena++;}
	while(aux >= 10)
		{aux-=10;dezena++;}
	unidade=aux;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *	                 		  Outras Funcoes					         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void escreve_frase(const rom char *frase)
{
	do
	{
	escreve_lcd(*frase);
	}while(*++frase);
}

void escreve_pwm(unsigned int v_pwm)
{
	unsigned short long pwm100;			// short long -> 24 bits
	pwm100=v_pwm;
	pwm100*=100;
	pwm100/=1023;
	converte_bcd((unsigned char)pwm100);
	comando_lcd(0xCA);
	escreve_lcd(centena + 0x30);
	escreve_lcd(dezena + 0x30);
	escreve_lcd(unidade + 0x30);

	if(ST_DIS)
	{
		pwm100=v_pwm;
		pwm100*=14;
		pwm100/=1023;
		escreve_graph((char)pwm100);
	}
	
	while(BusyUSART()) ClrWdt();
	putrsUSART("P=");
	while(BusyUSART()) ClrWdt();
	WriteUSART(centena+0x30);
	while(BusyUSART()) ClrWdt();
	WriteUSART(dezena+0x30);
	while(BusyUSART()) ClrWdt();
	WriteUSART(unidade+0x30);
}

void escreve_temp(unsigned int v_temp)
{
	unsigned int i_temp;
	unsigned char temp;

	i_temp=(v_temp >> 2);
	temp=temp_table[i_temp];
	converte_bcd(temp);
	comando_lcd(0xC3);
	if(!centena)
	{
		escreve_lcd(dezena + 0x30);
		escreve_lcd(unidade + 0x30);
	}
	else
		escreve_frase("HI");

	if(!ST_DIS)
	{
		if(temp<15) escreve_graph(0);
		else if(temp>45) escreve_graph(14);
			else
			{
				i_temp=temp-15;
				i_temp*=14;
				i_temp/=30;
				escreve_graph((char)i_temp);
			}
	}
	
	while(BusyUSART()) ClrWdt();
	putrsUSART(" T=");
	while(BusyUSART()) ClrWdt();
	WriteUSART(centena+0x30);
	while(BusyUSART()) ClrWdt();
	WriteUSART(dezena+0x30);
	while(BusyUSART()) ClrWdt();
	WriteUSART(unidade+0x30);
	while(BusyUSART()) ClrWdt();
	WriteUSART(0x0D);
	while(BusyUSART()) ClrWdt();
	WriteUSART(0x0A);
}

void inc_graph(void)
{
	if(pos_graph<14)					// somente ate a posicao 14
	{
		comando_lcd(0x80 | pos_graph);	// posiciona cursor
		escreve_lcd('*');				// adiciona asterisco
		pos_graph++;					// incrementa posicao
	}
}

void dec_graph(void)
{
	if(pos_graph!=0)					// somente ate a posicao 0
	{
		pos_graph--;					// decrementa posicao
		comando_lcd(0x80 | pos_graph);	// posiciona cursor
		escreve_lcd(' ');				// retira asterisco
	}
}

void escreve_graph(char n_ast)
{
 	char diferenca;

	if(n_ast <= 14)
	{
		diferenca=n_ast - pos_graph;
		while(diferenca > 0)
			{
				inc_graph();
				diferenca--;
			}
		while(diferenca < 0)
			{
				dec_graph();
				diferenca++;
			}
	}
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                            Fun��o Principal                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void main ()
{
	OpenADC(ADC_FOSC_32 & ADC_RIGHT_JUST & ADC_3ANA_0REF,
			ADC_CH1 & ADC_INT_OFF ); // CH1 - Potenciometro
									 // CH0 - Temperatura
	OpenUSART(USART_TX_INT_OFF  &
	          USART_RX_INT_OFF  &
	          USART_ASYNCH_MODE &
	          USART_EIGHT_BIT   &
	          USART_CONT_RX   	&
	          USART_BRGH_HIGH,25);

	
	OpenTimer2(TIMER_INT_OFF & T2_PS_1_16 & T2_POST_1_1);
	// Abre o Timer2, necessario para o PWM
	OpenPWM1(255);
	// Abre o PWM1 com PR2=255, Frequencia de 244 Hz para XTAL@4MHz
	SetDCPWM1(0);
	// Inicia o DutyCycle em 0

	PORTA = 0x00;                       //Clear PORTA
	PORTB = 0x00;                       //Clear PORTB
	PORTC = 0x00;		         	    //Clear PORTC
	PORTD = 0x00;                       //Clear PORTD
	PORTE = 0x00;                       //Clear PORTE

	LATA = 0x00;                      	//Clear LATCHA
	LATB = 0x00;                        //Clear LATCHB
	LATC = 0x00;		     	        //Clear LATCHC
	LATD = 0x00;                        //Clear LATCHD
	LATE = 0x00;                        //Clear LATCHE

	TRISA = 0b00101111;                 //CONFIG DIRE��O DOS PINOS PORTA
	TRISB = 0b00001111;                 //CONFIG DIRE��O DOS PINOS PORTB
	TRISC = 0b10011001;		            //CONFIG DIRE��O DOS PINOS PORTC
	TRISD = 0b00000000;                 //CONFIG DIRE��O DOS PINOS PORTD
	TRISE = 0b00000000;                 //CONFIG DIRE��O DOS PINOS PORTE	

	while(RCONbits.NOT_TO);				//aguarda estouro do WDT

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                        Inicializa��o do Sistema                     *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
	
	RCON = 0x7F;						// Reset CONtrol

	ST_MOD=0;							// inicia em modo local
	ST_DIS=0;							// inicia em display temperatura

	inicializa_lcd();					// configura o lcd

	tela_principal();					// monta tela principal
	
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                            Rotina Principal                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
   	
	for(;;)
	{
		ClrWdt();
		if(!ST_MOD)								// Modo local
		{
			SetChanADC( ADC_CH1 );				// Canal do Potenciometro
			Delay10TCYx(5);						// Aguarda acomodacao
			ConvertADC();						// Inicia convers�o AD
		
			while(BusyADC()){}
			valor_pwm=ReadADC();
			SetDCPWM1(valor_pwm);				// Aquecimento		
			escreve_pwm(valor_pwm);
		
			SetChanADC( ADC_CH0 );				// Canal da temperatura
			Delay10TCYx(5);						// Aguarda acomodacao
			ConvertADC();
			while(BusyADC()){}
			valor_temp=ReadADC();
			escreve_temp(valor_temp);

			if(DataRdyUSART())
			{
				if(getcUSART()=='R')
				{
					ST_MOD=1;	// Muda para remoto
					comando_lcd(0xCF);
					escreve_lcd('R');
				}
			}
		}

		else									// Modo remoto
		{

			SetDCPWM1(valor_pwm);				// Aquecimento		
			escreve_pwm(valor_pwm);

			ConvertADC();						// Esta em temperatura
			while(BusyADC()){}
			valor_temp=ReadADC();
			escreve_temp(valor_temp);
		
			if(DataRdyUSART())
			{
				comando=getcUSART();
				switch(comando)
				{
					case 'L':					// Muda para local
						ST_MOD=0;
						comando_lcd(0xCF);
						escreve_lcd('L');
						break;
					case 'I':					// Incrementa PWM
						valor_pwm+=10;
						if(valor_pwm>=1024) valor_pwm=1023;
						break;
					case 'D':					// Decrementa PWM
						if(valor_pwm<=10) valor_pwm=0;
						else valor_pwm-=10;
						break;
					case 'G':
						while(!DataRdyUSART()) ClrWdt();
						comando=getcUSART();
						switch(comando)
						{
							case 'T':
								ST_DIS=0;
								comando_lcd(0x8F);
								escreve_lcd('T');
								break;
							case 'P':
								ST_DIS=1;
								comando_lcd(0x8F);
								escreve_lcd('P');
								break;
						}
						break;
					case 'P':
						while(!DataRdyUSART()) ClrWdt();
						centena=getcUSART();
						if(!isdigit(centena)) break;
						while(!DataRdyUSART()) ClrWdt();
						dezena=getcUSART();
						if(!isdigit(dezena)) break;
						while(!DataRdyUSART()) ClrWdt();
						unidade=getcUSART();
						if(!isdigit(unidade)) break;
						while(!DataRdyUSART()) ClrWdt();
						if((comando=getcUSART())!=0x0D) break;
						valor_pwm=100*(centena-0x30)+10*(dezena-0x30)+(unidade-0x30);
						if(valor_pwm>100) valor_pwm=100;
						valor_pwm=(int)ceil(valor_pwm*10.23);
						break;
				}
			}



		}
	}											// FIM LA�O PRINCIPAL
}

