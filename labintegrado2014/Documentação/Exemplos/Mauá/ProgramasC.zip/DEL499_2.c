/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *           Programa��o em C18 - Recursos B�sicos de programa��o        *
 *                               DEL499_2.c                              *
 *                                                                       *
 *                			 MICROCONTROLADORES				             *
 *                                                                       *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *   VERS�O : 1.3 (Jos� Carlos)                                          *
 *   DATA : 29/09/2006                                          	   	 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                             Descri��o geral                           *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*	ESTE EXEMPLO FOI ELABORADO PARA EXPLICAR O FUNCIONAMENTO DA USART DO 
PIC. O SOFTWARE CONVERTE O CANAL 1 DO CONVERSOR A/D (POTENCI�METRO P2) E
MOSTRA NO DISPLAY O VALOR CONVERTIDO EM DECIMAL E HEXADECIMAL.AL�M DE 
MOSTRAR O VALOR NO DISPLAY, O SOFTWARE TRANSMITE PELA USART O VALOR
DA CONVERS�O. OS VALORES RECEBIDOS PELA USART TAMB�M S�O MOSTRADOS NO
LCD COMO CARACTERES ASCII.*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                		DEFINI��O PIC			         				 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <p18F452.h>        	 //Register definitions

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                INCLUDES DAS FUN��ES DE PERIF�RICOS DO PIC             *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
								 //N�o utilizaremos todas neste exemplo
#include <pwm.h>          		 //PWM library functions
#include <adc.h>           		 //ADC library functions
#include <timers.h>        		 //Timer library functions
#include <delays.h>           	 //Delay library functions
#include <i2c.h>           		 //I2C library functions
#include <stdlib.h>           	 //Library functions
#include <usart.h>           	 //USART library functions

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                         Configura��es para grava��o                   *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#pragma config OSC = XT
#pragma config WDT = ON
#pragma config WDTPS = 4
#pragma config LVP = OFF

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *              Defini��o e inicializa��o das vari�veis Globais          *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
//Neste bloco est�o definidas as vari�veis globais do programa.
//Este programa exemplo n�o utiliza nenhuma vari�vel local

unsigned char	unidade;
unsigned char	dezena;	
unsigned char	centena;
unsigned char	hexa_low;
unsigned char	hexa_high;

unsigned char	converte;
unsigned char	usart_rx;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                           Constantes internas                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
//A defini��o de constantes facilita a programa��o e a manuten��o.

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                    Declara��o dos flags de software                   *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
//A defini��o de flags ajuda na programa��o e economiza mem�ria RAM.
//Este programa n�o utiliza nenhum flag de usu�rio

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                   Defini��o e inicializa��o dos port's                *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                       PROTOTIPAGEM DE FUN��ES                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
void comando_lcd(unsigned char caracter);
void escreve_lcd(unsigned char caracter);
void limpa_lcd(void);
void inicializa_lcd(void);
void tela_principal(void);
void converte_bcd(unsigned char aux);
void converte_hexadecimal(unsigned char aux);
void escreve_frase(const rom char *frase);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                ENTRADAS                               *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// As entradas devem ser associadas a nomes para facilitar a programa��o e
//futuras altera��es do hardware.

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                 SA�DAS                                *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// AS SA�DAS DEVEM SER ASSOCIADAS A NOMES PARA FACILITAR A PROGRAMA��O E
//FUTURAS ALTERA��ES DO HARDWARE.

#define rs		PORTEbits.RE0	/* via do lcd que sinaliza recep��o de
								   dados ou comando */
#define enable	PORTEbits.RE1	// enable do lcd

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *					Rotina que envia um COMANDO para o LCD		         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void comando_lcd(unsigned char caracter)
{
	rs = 0;						// seleciona o envio de um comando
	PORTD = caracter;			// carrega o PORTD com o caracter
	enable = 1 ;				// gera pulso no enable
	Delay10TCYx(1);				// espera 10 microsegundos
	enable = 0;					// desce o pino de enable
	Delay10TCYx(4);				// espera m�nimo 40 microsegundos
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *				Rotina que envia um DADO a ser escrito no LCD            *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void escreve_lcd(unsigned char caracter)
{
	rs = 1;						// seleciona o envio de um dado
	PORTD = caracter;			// carrega o PORTD com o caracter
	enable = 1;					// gera pulso no enable
	Delay10TCYx(1);				// espera 10 microsegundos
	enable = 0;					// desce o pino de enable
	Delay10TCYx(4);				// espera m�nimo 40 microsegundos
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *						        Fun��o para limpar o LCD		         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void limpa_lcd(void)
{
	comando_lcd(0x01);			// limpa lcd	
	Delay1KTCYx(2);				// aguarda 2000 microsegundos (2ms)	
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *		     			Inicializa��o do Display de LCD			         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void inicializa_lcd(void)
{
	comando_lcd(0x30);			// envia comando para inicializar display
	Delay1KTCYx(4);				// espera 4 milisengundos

	comando_lcd(0x30);			// envia comando para inicializar display
	Delay10TCYx(10);			// espera 100 microsengundos

	comando_lcd(0x30);			// envia comando para inicializar display

	comando_lcd(0x38);			// liga o display, sem cursor e sem blink

	limpa_lcd();				// limpa lcd

	comando_lcd(0x0c);			// display sem cursor

	comando_lcd(0x06);			// desloca cursor para a direita
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *	                 		  Tela Principal					         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void tela_principal(void)
{
	comando_lcd(0x80);			// posiciona o cursor na linha 0, coluna 0
	escreve_frase("USART:9600,8,n,1");
	comando_lcd(0xC0);
	escreve_frase("TX:   d   h RX: ");
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *	                 		  Conversoes  						         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void converte_bcd(unsigned char aux)
{
	dezena = 0;
	centena = 0;
	while(aux >= 100)
	    {aux-=100;centena++;}
	while(aux >= 10)
		{aux-=10;dezena++;}
	unidade=aux;
}

void converte_hexadecimal(unsigned char aux)
{
	hexa_low = aux & 0b00001111; 	//Opera��o AND
	hexa_high = (aux >> 4);			//Deslocamento de 4 bits (insere '0's)
}

void escreve_frase(const rom char *frase)
{
	do
	{
	escreve_lcd(*frase);
	}while(*++frase);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                            Fun��o Principal                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void main ()
{
	OpenADC(ADC_FOSC_32 & ADC_LEFT_JUST & ADC_3ANA_0REF,
			ADC_CH1 & ADC_INT_OFF );

	OpenUSART(USART_TX_INT_OFF  &
	          USART_RX_INT_OFF  &
	          USART_ASYNCH_MODE &
	          USART_EIGHT_BIT   &
	          USART_CONT_RX   	&
	          USART_BRGH_HIGH,25);

	PORTA = 0x00;                       //Clear PORTA
	PORTB = 0x00;                       //Clear PORTB
	PORTC = 0x00;		         	    //Clear PORTC
	PORTD = 0x00;                       //Clear PORTD
	PORTE = 0x00;                       //Clear PORTE

	LATA = 0x00;                      	//Clear LATCHA
	LATB = 0x00;                        //Clear LATCHB
	LATC = 0x00;		     	        //Clear LATCHC
	LATD = 0x00;                        //Clear LATCHD
	LATE = 0x00;                        //Clear LATCHE

	TRISA = 0b00101111;                 //CONFIG DIRE��O DOS PINOS PORTA
	TRISB = 0b00001111;                 //CONFIG DIRE��O DOS PINOS PORTB
	TRISC = 0b10011001;		            //CONFIG DIRE��O DOS PINOS PORTC
	TRISD = 0b00000000;                 //CONFIG DIRE��O DOS PINOS PORTD
	TRISE = 0b00000000;                 //CONFIG DIRE��O DOS PINOS PORTE	

	while(RCONbits.NOT_TO);				//aguarda estouro do WDT

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                        Inicializa��o do Sistema                     *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
	
	RCON = 0x7F;						// Reset CONtrol

	inicializa_lcd();					// configura o lcd

	tela_principal();					// monta tela principal
	
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                            Rotina Principal                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
   	
	for(;;)
	{
		ClrWdt();
		ConvertADC();						//Inicia convers�o AD
		
		while(BusyADC())
		{
			if(DataRdyUSART())
			{
				usart_rx = ReadUSART();
				comando_lcd(0xCF);			// posiciona o cursor na
											// linha 2, coluna 16
				escreve_lcd(usart_rx);			
			}	
		}

		converte = ADRESH;
		converte_bcd(converte);
		comando_lcd(0xC3);				/* posiciona o cursor na 
											   linha 2, coluna 4 */
		escreve_lcd (centena + 0x30);	// imprime mensagem no lcd 
		escreve_lcd (dezena + 0x30);
		escreve_lcd (unidade + 0x30);

		converte_hexadecimal(ADRESH);
		comando_lcd(0xC8);					// posiciona o cursor na
											// linha 2, coluna 9
		if(hexa_high <= 9)	
			escreve_lcd (hexa_high + 0x30);
											// imprime mensagem no lcd 
		else escreve_lcd(hexa_high + 0x37);

		if(hexa_low <= 9)
			escreve_lcd (hexa_low + 0x30);
											// imprime mensagem no lcd 
		else escreve_lcd(hexa_low + 0x37);

		while(BusyUSART()) ClrWdt();

		WriteUSART(converte);

	}										// FIM LA�O PRINCIPAL
}
