#include<p18f452.h>
#include<delays.h>
#include<pwm.h>
#include<compare.h>
#include<timers.h>
#include<math.h>
#include<portb.h>

#pragma config WDT = OFF, LVP = OFF, OSC = XT, PWRT = ON, BOR = ON, BORV = 42

//Prot�tipos de fun��es
void ISR_High_Priority(void);
void ISR_Low_Priority(void);			
void inicia_lcd(void);			//Fun��o de inicializa��o do LCD
void escreve_comando(char c);	//Envia comando para o LCD
void escreve_dado(char d);		//Escrita de uma dado no LCD

//Defini��o de vari�veis globais
unsigned int dutyPWM = 0;
unsigned char W_temp, BSR_temp, STATUS_temp;
unsigned char div_freq_tmr0 = 20;
unsigned char decod[] = {'0','1','2','3','4','5','6','7','8','9'};

//----------------------------------------------------------------
#pragma code vec_int_high_priority = 0x08
void vec_int_high_priority(void)
{ _asm GOTO ISR_High_Priority _endasm }

#pragma code vec_int_low_priority = 0x18
void vec_int_low_priority(void)
{ _asm GOTO ISR_Low_Priority _endasm }

#pragma code
void ISR_High_Priority(void)
{
	INTCONbits.TMR0IF = 0;
	//WriteTimer0();
	//..
	_asm
	RETFIE 1
	_endasm
}

//----------------------------------------------------------------
void ISR_Low_Priority(void)
{
	_asm
	MOVFF	WREG,W_temp
	MOVFF	STATUS, STATUS_temp
	MOVFF	BSR, BSR_temp
	_endasm

	//;

	_asm
	MOVFF	W_temp, WREG
	MOVFF	STATUS_temp, STATUS
	MOVFF	BSR_temp, BSR
	RETFIE 0
	_endasm
}

//----------------------------------------------------------------
void main(void)
{
	ADCON1 = 0x07;		// PORTA como pinos digitais

	TRISA = 0xFF;
	TRISB = 0b00001100;
	TRISC = 0b11111001;
	TRISD = 0x00;
	TRISE = 0b00000000;

	PORTB = 0x00;
	PORTD = 0x00;	
	
	OpenTimer1(TIMER_INT_OFF & T1_16BIT_RW & T1_SOURCE_EXT
			& T1_PS_1_1 & T1_OSC1EN_OFF & T1_SOURCE_CCP);
	WriteTimer1(0);

	OpenCompare1(COM_INT_ON & COM_TRIG_SEVNT, 7);	//CCP1 como COMPARE e disparo de
													// TMR1 = CCP1H/L
													// e seta valor de compara��o

	IPR1bits.CCP1IP = 0;		//COMPARE � de baixa prioridade
	IPR2 = 0;					//Int. de perif�ricos � de baixa prioridade

	INTCON2 = 0b00000100;		//Int. TMR0 � de alta prioridade
	OpenTimer0(TIMER_INT_ON &				//Liga interrup��o
				T0_16BIT & T0_SOURCE_INT &	//Clock interno
				T0_PS_1_1);					//Prescaler 1:32

	WriteTimer0(15536);		//15536 = 65536 - 50000 (50000 ciclos de p/ estouro)

	PIR1bits.CCP1IF = 0;
	INTCONbits.TMR0IF = 0;		//Inicializa flags de interrup��es

	RCONbits.IPEN = 1;			//Habilita prioridade de interrup��es
	INTCONbits.GIE = 1;			//Habilita interrup��es de alta prioridade
	INTCONbits.PEIE = 1;		//Habilita interrup��es de baixa prioridade

	OpenPWM2(24);	//Tpwm = 25us => maxPWM = 100
	SetDCPWM2(dutyPWM);

	DisablePullups();
	inicia_lcd();

	while(1)	//Loop principal
	{
		while((PORTBbits.RB2 == 1) && (PORTBbits.RB3 == 1))
		{
			// Adicione aqui o que deve ser executado quando
			// as teclas estiverem soltas.
		}

		Delay1KTCYx(20);	//Delay para debounce das teclas

		if((PORTBbits.RB2 == 0) && (PORTBbits.RB3 == 1))
		{	//RB2 pressionado
			// Adicione aqui o que deve ser executado quando
			// as tecla RB2 for acionada.
		
		}
		else if((PORTBbits.RB2 == 1) && (PORTBbits.RB3 == 0))
		{	//RB3 pressionado
			// Adicione aqui o que deve ser executado quando
			// as tecla RB3 for acionada.
		}		

		while(((PORTBbits.RB2 == 0) || (PORTBbits.RB3 == 0))){}
		Delay1KTCYx(20);
		while(((PORTBbits.RB2 == 0) || (PORTBbits.RB3 == 0))){}		
	}

}

//----------------------------------------------------------------
//Fun��o de inicializa��o do LCD
void inicia_lcd(void)
{
	escreve_comando(0x38);
	Delay1KTCYx(3);
	escreve_comando(0x38);
	escreve_comando(0x06);
	escreve_comando(0x0C);
	escreve_comando(0x01);
	Delay1KTCYx(1);
	escreve_comando(0x80);	//Posiciona cursor

	escreve_dado('X');
}

//----------------------------------------------------------------
//Envia comando para o LCD
void escreve_comando(char c)
{
	PORTEbits.RE0=0;
	PORTD=c;
	Delay10TCYx(1);
	PORTEbits.RE1=1;
	Delay1TCY();
	Delay1TCY();
	Delay1TCY();
	PORTEbits.RE1=0;
	Delay1KTCYx(1);
}

//----------------------------------------------------------------
//Escrita de uma dado no LCD
void escreve_dado(char d)
{
PORTEbits.RE0=1;
PORTD=d;
Delay10TCYx(1);
PORTEbits.RE1=1;
Delay1TCY();
Delay1TCY();
Delay1TCY();
PORTEbits.RE1=0;
Delay1KTCYx(1);
PORTEbits.RE0=1;
}