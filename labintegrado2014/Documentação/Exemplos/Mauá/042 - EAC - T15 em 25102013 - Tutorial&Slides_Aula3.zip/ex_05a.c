//**************************************************************************
// Exemplo 5 (Exerc�cio):
//
// Este c�digo refere-se ao exerc�cio sobre convers�o A/D, temporizada
// atrav�s do recurso de interrup��o gerada por um timer.
//**************************************************************************
#include <p18F4550.h>           //Defini��o de registradores
#include <delays.h>		//Cabe�alho da biblioteca de fun��es de delay
#include <timers.h>
#include <adc.h>
#include "mylcdlib.h"	//Cabe�alho da biblioteca de fun��es do LCD

//***  Bits de configura��o do microcontrolador  ***************************

#pragma config FOSC = HS
#pragma config CPUDIV = OSC1_PLL2
#pragma config WDT = ON
#pragma config WDTPS = 128
#pragma config LVP = OFF
#pragma config PWRT = ON
#pragma config BOR = OFF
#pragma config BORV = 0
#pragma config PBADEN = OFF
#pragma config DEBUG = OFF
#pragma config PLLDIV = 1
#pragma config USBDIV = 1
#pragma config FCMEN = OFF
#pragma config IESO = OFF
#pragma config VREGEN = OFF
#pragma config MCLRE = ON
#pragma config LPT1OSC = OFF
#pragma config CCP2MX = ON
#pragma config STVREN = OFF
#pragma config ICPRT = OFF
#pragma config XINST = OFF

//*** Prot�tipos de fun��es ************************************************
//Fun��es para convers�o de dados e escrita no LCD
void ConverteBCD (unsigned int valor);
void TelaPrincipalLCD(void);
void EscreveAD (void);
//Fun��es para tratamento das interrup��es de alta prioridade 
void IntHighPriority (void); 
void Tratamento_Int_High(void); 

//*** Defini��es de uni�es(unions) *****************************************
union varbyte
{
	struct
	{
	    unsigned char BIT0 :1;
	    unsigned char BIT1 :1;
	    unsigned char BIT2 :1;
	    unsigned char BIT3 :1;
	    unsigned char BIT4 :1;
	    unsigned char BIT5 :1;
	    unsigned char BIT6 :1;
	    unsigned char BIT7 :1;
	};
	unsigned char byte;
};
//*** Defini��es de vari�veis globais e ************************************

unsigned int res;
unsigned char unidade, dezena, centena;	//Armazena convers�o BCD de res
unsigned char status;
union varbyte estado_teclas;


//*** Defini��es de constantes *********************************************


//*** Defini��es de I/Os ***************************************************

#define btinc	estado_teclas.BIT4	//Bit da mem�ria com o estado do RD4
#define btdec	estado_teclas.BIT5	//Bit da mem�ria com o estado do RD5
#define	coluna1	PORTDbits.RD0   //IO de ativa��o da coluna 1 do teclado
                                    //(1:coluna ativada)
                                    
//*** Tratamento de Inturrp��es de Alta Prioridade *************************
#pragma code Vetor_High_Priority = 0x0008    //VETOR DE ALTA PRIORIDADE 
void IntHighPriority (void) 
{ 
    _asm goto Tratamento_Int_High _endasm 
} 
  
#pragma interrupt Tratamento_Int_High 
void Tratamento_Int_High(void) 
{ 
    //Interrup��o de Timer0? 
    if(INTCONbits.TMR0IF) 
    { 
	    WriteTimer0(65536-31250);    //Seta a contagem para 500ms
        INTCONbits.TMR0IF = 0;
        
	    ConvertADC(); 			//Inicia a convers�o 
	    while(BusyADC()) {};	//Aguarda o fim da convers�o 
	    res = ReadADC();		//Armazena o resultado em res 
	  
	    status = 1;  
    } 
}

//**************************************************************************
void main(void)
{
    PORTA = 0x00;               //Limpa PORTA
    PORTB = 0x00;               //Limpa PORTB
    PORTC = 0x00;               //Limpa PORTC
    PORTD = 0x00;               //Limpa PORTD
    PORTE = 0x00;               //Limpa PORTE

    TRISA = 0b11000011;         //CONFIG DIRE��O DOS PINOS PORTA
    TRISB = 0b00000000;         //CONFIG DIRE��O DOS PINOS PORTB
    TRISC = 0b11111111;         //CONFIG DIRE��O DOS PINOS PORTC
    TRISD = 0b00000000;         //CONFIG DIRE��O DOS PINOS PORTD
    TRISE = 0b00000100;         //CONFIG DIRE��O DOS PINOS PORTE

//Configura��o do Timer0 
    OpenTimer0( TIMER_INT_ON &  //Interrup��o ligada 
                T0_16BIT &       //16-bits                 
                T0_SOURCE_INT & //Tosc como clock source 
                T0_PS_1_16);    //Prescaler 1:16 
      
    WriteTimer0(65536-31250);    //Inicia a contagem para 500ms
    INTCONbits.TMR0IF = 0;      //Inicializa flags de interrup��es
    INTCONbits.GIE = 1; //Ativa interrup��es
    
    OpenADC(ADC_FOSC_8 & ADC_RIGHT_JUST & ADC_0_TAD,
    		ADC_CH0 & ADC_INT_OFF & ADC_VREFPLUS_VDD & ADC_VREFMINUS_VSS,
    		ADC_1ANA);     //Config. do ADC

//*** Inicializa��o do LCD
	InicializaLCD();
	TelaPrincipalLCD();

//*** Inicializa��o de vari�veis
	res = 0;
    
//*** Loop principal
    while(1)
    {
        ClrWdt();
        
        if(status)
        {
	        status = 0;
        	EscreveAD();	//escreve o valor atual do contador no LCD
		}
        
    }
} // bloco de c�digo da fun��o main

//*** Escreve a tela principal do LCD ***********************************
void TelaPrincipalLCD(void)
{
    ComandoLCD(0x80);    // Posiciona o cursor na linha 0, coluna 0
    EscreveLCD('C');
    EscreveLCD('o');
    EscreveLCD('n');
    EscreveLCD('v');
    EscreveLCD('.');
    EscreveLCD(' ');
    EscreveLCD('A');
    EscreveLCD('/');
    EscreveLCD('D');	// Imprime mensagem no lcd
}

//*** Converte um inteiro em dezena e unidade para escrita
// no LCD. Converte valores entre 0 e 999.
void ConverteBCD (unsigned int aux)
{

	unidade = 0;
    dezena = 0;
    centena = 0;
    aux = ((long) aux*500)/1023;
    if(aux == 0)return;
    while(aux--)
    {
        unidade++;
        if(unidade != 10)continue;
        unidade = 0;
        dezena++;
        if (dezena != 10)continue;
        dezena = 0;
        centena++;
        if (centena != 10)continue;
        centena = 0;
    }
}

//*** Escreve o valor do contador no LCD ***********************************
void EscreveAD (void)
{
	unsigned int valorAD = res;
	ConverteBCD(valorAD);	//Separa os valor de dezena e
							//unidade para escrever no LCD
	ComandoLCD(0xC6);		//Posiciona o cursor na linha 1, coluna 6
	EscreveLCD(centena + 0x30);
	EscreveLCD('.');
	EscreveLCD(dezena + 0x30);
	EscreveLCD(unidade + 0x30);
	EscreveLCD('V');
}
