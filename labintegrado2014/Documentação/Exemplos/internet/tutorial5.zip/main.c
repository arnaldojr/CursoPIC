//    Tutorial5.asm - A/D delayed LED Blink in C
//    Copyright (C) 2010 www.pic18f.com
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
///////////////////////////////////////////////////////////////////////////


#include <p18f4550.h>
#include <delays.h>

#pragma config FOSC = INTOSCIO_EC //Internal oscillator, port function on RA6, EC used by USB 
#pragma config WDT = OFF //Disable watchdog timer

#define LEDPin LATDbits.LATD1 //Define LEDPin as PORT D Pin 1
#define LEDTris TRISDbits.TRISD1 //Define LEDTris as TRISD Pin 1

void main()
{
	int delay;
	
	LEDTris = 0;//Set LED Pin data direction to OUTPUT
	LEDPin = 1;//Set LED Pin
	
	ADCON1 = 0b00001110;//VSS,VDD ref. AN0 analog only
	ADCON0 = 0x00;//clear ADCON0 to select channel 0 (AN0)
	ADCON2 = 0b00001000;//ADCON2 setup: Left justified, Tacq=2Tad, Tad=2*Tosc (or Fosc/2)
	ADCON0bits.ADON = 0x01;//Enable A/D module
	
	while(1)
	{
		ADCON0bits.GO_DONE = 1;//Start A/D Conversion
		
		while(ADCON0bits.GO_DONE != 0);//Loop here until A/D conversion completes
		delay = ADRESH;//Set the delay to the 8 MSB
		
		LEDPin = ~LEDPin;//Toggle LED Pin
		if (delay > 0)
			Delay1KTCYx(delay);//Delay (argument of 250 will delay 1 second at 1MHz since each instruction takes 4 cycles)
	}

}