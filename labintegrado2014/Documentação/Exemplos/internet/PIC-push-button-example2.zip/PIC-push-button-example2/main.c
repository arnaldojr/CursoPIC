
//////////////////////////////////////////////////////////
// Designed by www.MCUExamples.com
// rasika0612@gmail.com
//////////////////////////////////////////////////////////

#include <p18f2520.h>

#pragma config OSC    = XT  // 4MHz Crystal, (XT oscillator)
#pragma config PBADEN = OFF // PORTB<4:0> pins are configured as digital I/O on Reset)


void delay_ms(unsigned int duration);
unsigned char is_sw1_pressed(void);
unsigned char is_sw2_pressed(void);


void main()
{
   TRISCbits.TRISC0=0; // Set PortC bit 0 as output, LED1 is connected to thi pin
   TRISCbits.TRISC1=0; // Set PortC bit 0 as output, LED2 is connected to thi pin
	
   PORTCbits.RC0=0; // turn off LED1
   PORTCbits.RC1=0; // turn off LED2

   TRISBbits.TRISB3=1; // configure SW1 pin as input
   TRISBbits.TRISB4=1; // configure SW2 pin as input
	
	while(1)
	{
      if(is_sw1_pressed()==1)	// is key 1 pressed
      {						// yes
         PORTCbits.RC0=1; 	// turn ON LED1	
		}
		else
		{						//no
			PORTCbits.RC0=0;	//turn off LED1
		}

		if(is_sw2_pressed()==1)	// is key 2 pressed
		{						// yes
			PORTCbits.RC1=1; 	// turn ON LED2	
		}
		else
		{						//no
			PORTCbits.RC1=0;	//turn off LED2
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////////
// 	this is delay routine
// 	input: required Delay duration in mili Seconds
//	output: none
/////////////////////////////////////////////////////////////////////////////////////////

void delay_ms(unsigned int duration) // delay in miliseconds for 4.0MHZ crystal
{
	unsigned int i;
	for(;duration!=0;duration--)
	{
		for(i=0;i<=50;i++)
		{
			_asm
				nop
				nop
				nop
			_endasm
		}
		_asm
			nop
			nop
		_endasm
	}
}


/////////////////////////////////////////////////////////////////////////////////////////
//this routine is to check key1 pressings.
//input: none 
//output: 0 if switch is not pressed. 1 if switch is pressed. 
/////////////////////////////////////////////////////////////////////////////////////////
unsigned char is_sw1_pressed(void)
{
	if (PORTBbits.RB3==0)		// is SW1 pressed?
	{							//yes
		delay_ms(10);			// wait 10mS for debounce.
		if (PORTBbits.RB3==0)	// is SW1 still has pressed status after 10mS delay?
		{						// yes, we have key press
			return 1;
		}
	}
	return 0;// if key is not pressed, return 0
}

/////////////////////////////////////////////////////////////////////////////////////////
//this routine is to check key2 pressings.
//input: none 
//output: 0 if switch is not pressed. 1 if switch is pressed. 
/////////////////////////////////////////////////////////////////////////////////////////
unsigned char is_sw2_pressed(void)
{
	if (PORTBbits.RB4==0)		// is SW1 pressed?
	{							//yes
		delay_ms(10);			// wait 10mS for debounce.
		if (PORTBbits.RB4==0)	// is SW1 still has pressed status after 10mS delay?
		{						// yes, we have key press
			return 1;
		}
	}
	return 0;// if key is not pressed, return 0
}

