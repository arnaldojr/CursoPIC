//
// Designed by www.MCUExamples.com
// rasika0612@gmail.com
//

#include <p18f4520.h>

#pragma config OSC 		=	XT 	// 4MHz Crystal, (XT oscillator)
#pragma config PBADEN	=	OFF // PORTB<4:0> pins are configured as digital I/O on Reset)

void delay_ms(unsigned int duration);

void main()
{
	TRISC=0;
	while (1)
	{
		PORTC=0xff; 	//Set all pins of portC to logic high
		delay_ms(500); 	// delay 500mS
		PORTC=0;		//Set all pins of portC to logic low
		delay_ms(500);	// delay 500mS
	}
}

void delay_ms(unsigned int duration) // delay in miliseconds for 4.0MHZ crystal
{
	unsigned int i;
	for(;duration!=0;duration--)
	{
		for(i=0;i<=50;i++)
		{
			_asm
				nop
				nop
				nop
			_endasm
		}
		_asm
			nop
			nop
		_endasm
	}
}