/*********************************************************************
 *
 *	Hardware specific definitions
 *
 *********************************************************************
 * FileName:        HardwareProfile.h
 * Dependencies:    None
 * Processor:       PIC18, PIC24F, PIC24H, dsPIC30F, dsPIC33F, PIC32
 * Compiler:        Microchip C32 v1.00 or higher
 *					Microchip C30 v3.01 or higher
 *					Microchip C18 v3.13 or higher
 *					HI-TECH PICC-18 STD 9.50PL3 or higher
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * Copyright (C) 2002-2008 Microchip Technology Inc.  All rights 
 * reserved.
 *
 * Microchip licenses to you the right to use, modify, copy, and 
 * distribute: 
 * (i)  the Software when embedded on a Microchip microcontroller or 
 *      digital signal controller product ("Device") which is 
 *      integrated into Licensee's product; or
 * (ii) ONLY the Software driver source files ENC28J60.c and 
 *      ENC28J60.h ported to a non-Microchip device used in 
 *      conjunction with a Microchip ethernet controller for the 
 *      sole purpose of interfacing with the ethernet controller. 
 *
 * You should refer to the license agreement accompanying this 
 * Software for additional information regarding your rights and 
 * obligations.
 *
 * THE SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT 
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT 
 * LIMITATION, ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT SHALL 
 * MICROCHIP BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR 
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF 
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS 
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE 
 * THEREOF), ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER 
 * SIMILAR COSTS, WHETHER ASSERTED ON THE BASIS OF CONTRACT, TORT 
 * (INCLUDING NEGLIGENCE), BREACH OF WARRANTY, OR OTHERWISE.
 *
 *
 * Author               Date		Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Howard Schlunder		10/03/06	Original, copied from Compiler.h
 ********************************************************************/
#ifndef __HARDWARE_PROFILE_H
#define __HARDWARE_PROFILE_H

// Choose which hardware profile to compile for here.  See 
// the hardware profiles below for meaning of various options.  
//#define PICDEMNET2
//#define HPC_EXPLORER
//#define PICDEMZ
//#define PIC24FJ64GA004_PIM	// Explorer 16, but with the PIC24FJ64GA004 PIM module, which has significantly differnt pin mappings
//#define EXPLORER_16		// PIC24FJ128GA010, PIC24HJ256GP610, dsPIC33FJ256GP710 PIMs
//#define DSPICDEM11
#define YOUR_BOARD


#if defined(YOUR_BOARD)
// Define your own board hardware profile here

// Define your own board hardware profile here


#define GetSystemClock()		(16000000ul)      // Hz
#define GetInstructionClock()	(GetSystemClock()/4)
#define GetPeripheralClock()	GetInstructionClock()

// Hardware I/O pin mappings

// LEDs
#define LED0_TRIS           (TRISDbits.TRISD0)   // Ref D1
#define LED0_IO             (LATDbits.LATD0)
#define LED1_TRIS           (TRISDbits.TRISD1)   // Ref D2
#define LED1_IO             (LATDbits.LATD1)
#define LED2_TRIS           (TRISDbits.TRISD2)   // Ref D3
#define LED2_IO             (LATDbits.LATD2)
#define LED3_TRIS           (TRISDbits.TRISD3)   // Ref D4
#define LED3_IO             (LATDbits.LATD3)
#define LED4_TRIS           (TRISDbits.TRISD4)   // Ref D5
#define LED4_IO             (LATDbits.LATD4)
#define LED5_TRIS           (TRISDbits.TRISD5)   // Ref D6
#define LED5_IO             (LATDbits.LATD5)
#define LED6_TRIS           (TRISDbits.TRISD6)   // Ref D7
#define LED6_IO             (LATDbits.LATD6)
#define LED7_TRIS           (TRISDbits.TRISD7)   // Ref D8
#define LED7_IO             (LATDbits.LATD7)
#define LED_GET()           (LATD)
#define LED_PUT(a)          (LATD = (a))

// Reles da placa

#define RELE1           (LATBbits.LATB4)
#define RELE1_TRIS      (TRISBbits.TRISB4)

#define RELE2           (LATBbits.LATB5)
#define RELE2_TRIS      (TRISBbits.TRISB5)

#define VENTILADOR      (LATCbits.LATC1)
#define VENTILADOR_TRIS (TRISCbits.TRISC1)

// Momentary push buttons
#define BUTTON0_TRIS        (TRISBbits.TRISB2)
#define   BUTTON0_IO        (PORTBbits.RB2)
#define BUTTON1_TRIS        (TRISBbits.TRISB)
#define   BUTTON1_IO        (PORTBbits.RB3)
#define BUTTON2_TRIS        (TRISEbits.TRISE2)   // No Button2 on this board
#define   BUTTON2_IO        (1u)
#define BUTTON3_TRIS        (TRISEbits.TRISE2)   // No Button3 on this board
#define   BUTTON3_IO        (1u)      

// ENC28J60 I/O pins

#define ENC_RST_TRIS        (TRISEbits.TRISE2)
//#define ENC_RST_IO        (LATEbits.LATE2)
#define ENC_CS_TRIS         (TRISAbits.TRISA3)
#define ENC_CS_IO           (LATAbits.LATA3)
#define ENC_SCK_TRIS        (TRISCbits.TRISC3)
#define ENC_SDI_TRIS        (TRISCbits.TRISC4)
#define ENC_SDO_TRIS        (TRISCbits.TRISC5)
#define ENC_SPI_IF          (PIR1bits.SSPIF)
#define ENC_SSPBUF          (SSPBUF)
#define ENC_SPISTAT         (SSPSTAT)
#define ENC_SPISTATbits     (SSPSTATbits)
#define ENC_SPICON1         (SSPCON1)
#define ENC_SPICON1bits     (SSPCON1bits)
#define ENC_SPICON2         (SSPCON2)

// 25LC256 I/O pins
#define EEPROM_CS_TRIS      (TRISAbits.TRISA5)
#define EEPROM_CS_IO        (LATAbits.LATA5)
#define EEPROM_SCK_TRIS     (TRISCbits.TRISC3)
#define EEPROM_SDI_TRIS     (TRISCbits.TRISC4)
#define EEPROM_SDO_TRIS     (TRISCbits.TRISC5)
#define EEPROM_SPI_IF       (PIR1bits.SSPIF)
#define EEPROM_SSPBUF       (SSPBUF)
#define EEPROM_SPICON1      (SSPCON1)
#define EEPROM_SPICON1bits  (SSPCON1bits)
#define EEPROM_SPICON2      (SSPCON2)
#define EEPROM_SPISTAT      (SSPSTAT)
#define EEPROM_SPISTATbits  (SSPSTATbits)
   
// UART mapping functions for consistent API names across 8-bit and 16 or 
// 32 bit compilers.  For simplicity, everything will use "UART" instead 
// of USART/EUSART/etc.
#define BusyUART()          BusyUSART()
#define CloseUART()         CloseUSART()
#define ConfigIntUART(a)    ConfigIntUSART(a)
#define DataRdyUART()       DataRdyUSART()
#define OpenUART(a,b,c)     OpenUSART(a,b,c)
#define ReadUART()          ReadUSART()
#define WriteUART(a)        WriteUSART(a)
#define getsUART(a,b,c)     getsUSART(b,a)
#define putsUART(a)         putsUSART(a)
#define getcUART()          ReadUSART()
#define putcUART(a)         WriteUSART(a)
#define putrsUART(a)        putrsUSART((far rom char*)a)

#else
	#error "Hardware profile not defined.  See available profiles in HardwareProfile.h.  Add the appropriate macro definition to your application configuration file ('TCPIPConfig.h', etc.)"
#endif


#if defined(__18CXX)	// PIC18
	// UART mapping functions for consistent API names across 8-bit and 16 or 
	// 32 bit compilers.  For simplicity, everything will use "UART" instead 
	// of USART/EUSART/etc.
	#define BusyUART()				BusyUSART()
	#define CloseUART()				CloseUSART()
	#define ConfigIntUART(a)		ConfigIntUSART(a)
	#define DataRdyUART()			DataRdyUSART()
	#define OpenUART(a,b,c)			OpenUSART(a,b,c)
	#define ReadUART()				ReadUSART()
	#define WriteUART(a)			WriteUSART(a)
	#define getsUART(a,b,c)			getsUSART(b,a)
	#define putsUART(a)				putsUSART(a)
	#define getcUART()				ReadUSART()
	#define putcUART(a)				WriteUSART(a)
	#define putrsUART(a)			putrsUSART((far rom char*)a)

#else	 // PIC24F, PIC24H, dsPIC30, dsPIC33, PIC32
	// Some A/D converter registers on dsPIC30s are named slightly differently 
	// on other procesors, so we need to rename them.
	#if defined(__dsPIC30F__)
		#define ADC1BUF0			ADCBUF0
		#define AD1CHS				ADCHS
		#define	AD1CON1				ADCON1
		#define AD1CON2				ADCON2
		#define AD1CON3				ADCON3
		#define AD1PCFGbits			ADPCFGbits
		#define AD1CSSL				ADCSSL
		#define AD1IF				ADIF
		#define AD1IE				ADIE
		#define _ADC1Interrupt		_ADCInterrupt
	#endif

	// Select which UART the STACK_USE_UART and STACK_USE_UART2TCP_BRIDGE 
	// options will use.  You can change these to U1BRG, U1MODE, etc. if you 
	// want to use the UART1 module instead of UART2.
	#define UBRG					U2BRG
	#define UMODE					U2MODE
	#define USTA					U2STA
	#define BusyUART()				BusyUART2()
	#define CloseUART()				CloseUART2()
	#define ConfigIntUART(a)		ConfigIntUART2(a)
	#define DataRdyUART()			DataRdyUART2()
	#define OpenUART(a,b,c)			OpenUART2(a,b,c)
	#define ReadUART()				ReadUART2()
	#define WriteUART(a)			WriteUART2(a)
	#define getsUART(a,b,c)			getsUART2(a,b,c)
	#if defined(__C32__)
		#define putsUART(a)			putsUART2(a)
	#else
		#define putsUART(a)			putsUART2((unsigned int*)a)
	#endif
	#define getcUART()				getcUART2()
	#define putcUART(a)				WriteUART(a)
	#define putrsUART(a)			putsUART(a)
#endif


#endif
